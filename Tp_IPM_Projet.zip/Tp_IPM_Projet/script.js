function remplirAccueil() {

    // date d'aujourd'hui
    var date = new Date();
    //trouver le jour en 2 digits
    var day = date.getDate()
    if (date.getDate() < 10)
        day = '0' + date.getDate()
    //trouver le mois en 2 digits
    var month = date.getMonth() + 1
    if (date.getMonth() < 10)
        month = '0' + (date.getMonth() + 1)
    //trouver les journées
    if (date.getDay() == 1) {
        var journee = "Lundi";
    } else if (date.getDay() == 2) {
        var journee = "Mardi";
    } else if (date.getDay() == 3) {
        var journee = "Mercredi";
    } else if (date.getDay() == 4) {
        var journee = "Jeudi";
    } else if (date.getDay() == 5) {
        var journee = "Vendredi";
    } else if (date.getDay() == 6) {
        var journee = "Samedi";
    } else if (date.getDay() == 0) {
        var journee = "Dimanche";
    }

    var today = date.getFullYear() + '-' + month + '-' + day;


    //le parent 
    let parentDate = document.getElementById('date');
    //Créer enfant
    let paragDate = document.createElement('p');
    paragDate.innerHTML = journee + ", " + "Le " + day + "-" + month + "-" + date.getFullYear();
    paragDate.setAttribute('style', 'font-weight:bold')
    //Attacher enfant à parent 
    parentDate.appendChild(paragDate);


    fetch('fichier/temperatures_2022.json')
        .then(resp => { return resp.json() })
        .then(data => {
            let divIcon = document.getElementById('icon');
            for (let i = 0; i < data.temperatures.length; i++) {
                if (data.temperatures[i].DateDuJour == today) {
                    let icon = document.createElement('img');
                    if (data.temperatures[i].Temp <= 0) {
                        icon.setAttribute('src', 'img/neige.png');
                    } else if (data.temperatures[i].Temp >= 20) {
                        icon.setAttribute('src', 'img/soleil2.png');
                    } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                        icon.setAttribute('src', 'img/pluie.png');
                    } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                        icon.setAttribute('src', 'img/nuage.png');
                    }

                    divIcon.appendChild(icon);
                }
            }

            let divTemp = document.getElementById('temp');
            for (let i = 0; i < data.temperatures.length; i++) {
                if (data.temperatures[i].DateDuJour == today) {
                    let paragTemp = document.createElement('p');
                    let paragMinTemp = document.createElement('p');
                    let paragMaxTemp = document.createElement('p');

                    paragTemp.innerHTML = "Tempertaure actuel: " + data.temperatures[i].Temp + " °C";
                    paragMinTemp.innerHTML = "Tempertaure Minimum: " + data.temperatures[i].MinTemp + " °C";
                    paragMaxTemp.innerHTML = "Tempertaure Maximum: " + data.temperatures[i].MaxTemp + " °C";

                    paragTemp.setAttribute('class', 'fw-bolder fs-3')

                    divTemp.appendChild(paragTemp);
                    divTemp.appendChild(paragMinTemp);
                    divTemp.appendChild(paragMaxTemp);
                }
            }
        })
}

function remplir3Jours() {
    fetch('fichier/temperatures_2022.json')
        .then(resp => { return resp.json() })
        .then(data => {
            let tab = ['jour1', 'jour2', 'jour3'];
            for (let index = 0; index < tab.length; index++) {

                // date d'aujourd'hui
                var date = new Date();
                //trouver le jour en 2 digits
                var day = date.getDate() + index

                //trouver le mois en 2 digits
                var month = date.getMonth() + 1

                if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                    if (day > 31) {
                        let x = day - 31;
                        day = x;
                        month += 1;
                    }
                } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                    if (day > 30) {
                        let x = day - 31;
                        day = x;
                        month += 1;
                    }
                } else if (month == 2) {
                    if (day > 28) {
                        let x = day - 28;
                        day = x;
                        month += 1;
                    }
                }

                if (day < 10) {
                    day = '0' + day;
                }

                if (date.getMonth() < 10)
                    month = '0' + (date.getMonth() + 1)

                //trouver les journées
                if (date.getDay() == 1) {
                    var journee = "Lundi";
                } else if (date.getDay() == 2) {
                    var journee = "Mardi";
                } else if (date.getDay() == 3) {
                    var journee = "Mercredi";
                } else if (date.getDay() == 4) {
                    var journee = "Jeudi";
                } else if (date.getDay() == 5) {
                    var journee = "Vendredi";
                } else if (date.getDay() == 6) {
                    var journee = "Samedi";
                } else if (date.getDay() == 0) {
                    var journee = "Dimanche";
                }

                var today = date.getFullYear() + '-' + month + '-' + day;

                let id = tab[index];
                let divJour = document.getElementById(id);
                let dateJour = document.createElement('p');
                dateJour.innerHTML = today;
                dateJour.setAttribute('style', 'font-weight:bold; text-align:center;')
                divJour.appendChild(dateJour);

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let icon = document.createElement('img');
                        if (data.temperatures[i].Temp <= 0) {
                            icon.setAttribute('src', 'img/neige.png');
                        } else if (data.temperatures[i].Temp >= 20) {
                            icon.setAttribute('src', 'img/soleil2.png');
                        } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                            icon.setAttribute('src', 'img/pluie.png');
                        } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                            icon.setAttribute('src', 'img/nuage.png');
                        }

                        
                        divJour.appendChild(icon);
                    }

                }

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let paragTemp = document.createElement('p');
                        let paragMinTemp = document.createElement('p');
                        let paragMaxTemp = document.createElement('p');

                        paragTemp.innerHTML = "Tempertaure actuel: " + data.temperatures[i].Temp + " °C";
                        paragMinTemp.innerHTML = "Tempertaure Minimum: " + data.temperatures[i].MinTemp + " °C";
                        paragMaxTemp.innerHTML = "Tempertaure Maximum: " + data.temperatures[i].MaxTemp + " °C";

                        paragTemp.setAttribute('class', 'fw-bolder fs-3')

                        divJour.appendChild(paragTemp);
                        divJour.appendChild(paragMinTemp);
                        divJour.appendChild(paragMaxTemp);
                    }
                }

            }

        })
}


function remplir7Jours() {
    fetch('fichier/temperatures_2022.json')
        .then(resp => { return resp.json() })
        .then(data => {
            let tab = ['jour1', 'jour2', 'jour3', 'jour4', 'jour5', 'jour6', 'jour7'];
            for (let index = 0; index < tab.length; index++) {

                // date d'aujourd'hui
                var date = new Date();
                //trouver le jour en 2 digits
                var day = date.getDate() + index;

                //trouver le mois en 2 digits
                var month = date.getMonth() + 1;

                if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                    if (day > 31) {
                        let x = day - 31;
                        day = x;
                        month += 1;
                    }
                } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                    if (day > 30) {
                        let x = day - 30;
                        day = x;
                        month += 1;
                    }
                } else if (month == 2) {
                    if (day > 28) {
                        let x = day - 28;
                        day = x;
                        month += 1;
                    }
                }

                if (day < 10) {
                    day = '0' + day;
                }

                if (date.getMonth() < 10)
                    month = '0' + (date.getMonth() + 1)
                //trouver les journées
                if (date.getDay() == 1) {
                    var journee = "Lundi";
                } else if (date.getDay() == 2) {
                    var journee = "Mardi";
                } else if (date.getDay() == 3) {
                    var journee = "Mercredi";
                } else if (date.getDay() == 4) {
                    var journee = "Jeudi";
                } else if (date.getDay() == 5) {
                    var journee = "Vendredi";
                } else if (date.getDay() == 6) {
                    var journee = "Samedi";
                } else if (date.getDay() == 0) {
                    var journee = "Dimanche";
                }

                var today = date.getFullYear() + '-' + month + '-' + day;

                let id = tab[index];
                let divJour = document.getElementById(id);
                let dateJour = document.createElement('p');
                dateJour.innerHTML = today;
                dateJour.setAttribute('style', 'font-weight:bold; text-align:center;')
                divJour.appendChild(dateJour);

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let icon = document.createElement('img');
                        if (data.temperatures[i].Temp <= 0) {
                            icon.setAttribute('src', 'img/neige.png');
                        } else if (data.temperatures[i].Temp >= 20) {
                            icon.setAttribute('src', 'img/soleil2.png');
                        } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                            icon.setAttribute('src', 'img/pluie.png');
                        } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                            icon.setAttribute('src', 'img/nuage.png');
                        }

                        divJour.appendChild(icon);
                    }

                }

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let paragTemp = document.createElement('p');
                        let paragMinTemp = document.createElement('p');
                        let paragMaxTemp = document.createElement('p');

                        paragTemp.innerHTML = "Tempertaure actuel: " + data.temperatures[i].Temp + " °C";
                        paragMinTemp.innerHTML = "Tempertaure Minimum: " + data.temperatures[i].MinTemp + " °C";
                        paragMaxTemp.innerHTML = "Tempertaure Maximum: " + data.temperatures[i].MaxTemp + " °C";

                        paragTemp.setAttribute('class', 'fw-bolder fs-5')

                        divJour.appendChild(paragTemp);
                        divJour.appendChild(paragMinTemp);
                        divJour.appendChild(paragMaxTemp);
                    }
                }

            }

        })
}



function remplir14Jours() {
    fetch('fichier/temperatures_2022.json')
        .then(resp => { return resp.json() })
        .then(data => {
            let tab = ['jour1', 'jour2', 'jour3', 'jour4', 'jour5', 'jour6', 'jour7', 'jour8', 'jour9', 'jour10', 'jour11', 'jour12', 'jour13', 'jour14'];
            for (let index = 0; index < tab.length; index++) {

                // date d'aujourd'hui
                var date = new Date();
                //trouver le jour en 2 digits
                var day = date.getDate() + index;

                //trouver le mois en 2 digits
                var month = date.getMonth() + 1;

                if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
                    if (day > 31) {
                        let x = day - 31;
                        day = x;
                        month += 1;
                    }
                } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                    if (day > 30) {
                        let x = day - 30;
                        day = x;
                        month += 1;
                    }
                } else if (month == 2) {
                    if (day > 28) {
                        let x = day - 28;
                        day = x;
                        month += 1;
                    }
                }

                if (day < 10) {
                    day = '0' + day;
                }

                if (month < 10)
                    month = '0' + (date.getMonth() + 1)
                //trouver les journées
                if (date.getDay() == 1) {
                    var journee = "Lundi";
                } else if (date.getDay() == 2) {
                    var journee = "Mardi";
                } else if (date.getDay() == 3) {
                    var journee = "Mercredi";
                } else if (date.getDay() == 4) {
                    var journee = "Jeudi";
                } else if (date.getDay() == 5) {
                    var journee = "Vendredi";
                } else if (date.getDay() == 6) {
                    var journee = "Samedi";
                } else if (date.getDay() == 0) {
                    var journee = "Dimanche";
                }

                var today = date.getFullYear() + '-' + month + '-' + day;

                let id = tab[index];
                let divJour = document.getElementById(id);
                let dateJour = document.createElement('p');
                dateJour.innerHTML = today;
                dateJour.setAttribute('style', 'font-weight:bold; text-align:center;')
                divJour.appendChild(dateJour);

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let icon = document.createElement('img');
                        if (data.temperatures[i].Temp <= 0) {
                            icon.setAttribute('src', 'img/neige.png');
                        } else if (data.temperatures[i].Temp >= 20) {
                            icon.setAttribute('src', 'img/soleil2.png');
                        } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                            icon.setAttribute('src', 'img/pluie.png');
                        } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                            icon.setAttribute('src', 'img/nuage.png');
                        }

                        divJour.appendChild(icon);
                    }

                }

                for (let i = 0; i < data.temperatures.length; i++) {

                    if (data.temperatures[i].DateDuJour == today) {
                        let paragTemp = document.createElement('p');
                        let paragMinTemp = document.createElement('p');
                        let paragMaxTemp = document.createElement('p');

                        paragTemp.innerHTML = "Tempertaure actuel: " + data.temperatures[i].Temp + " °C";
                        paragMinTemp.innerHTML = "Tempertaure Minimum: " + data.temperatures[i].MinTemp + " °C";
                        paragMaxTemp.innerHTML = "Tempertaure Maximum: " + data.temperatures[i].MaxTemp + " °C";

                        paragTemp.setAttribute('class', 'fw-bolder fs-5')

                        divJour.appendChild(paragTemp);
                        divJour.appendChild(paragMinTemp);
                        divJour.appendChild(paragMaxTemp);
                    }
                }

            }

        })
}


function remplirMensuel() {
    fetch('fichier/temperatures_2022.json')
        .then(resp => { return resp.json() })
        .then(data => {

            let url = window.location.pathname;
        
            let chaudJan =  data.temperatures[0].MaxTemp;
            let froidJan =  data.temperatures[0].MinTemp;
            let moyJan = 0;
            let jourLePlusChaud = ' ';
            let jourLePlusFroid = ' ';

            let chaudFev = data.temperatures[31].MaxTemp;
            let froidFev = data.temperatures[31].MinTemp;
            let moyFev = 0;

            let chaudMar = data.temperatures[59].MaxTemp;
            let froidMar = data.temperatures[59].MinTemp;
            let moyMar = 0;

            let chaudAvr = data.temperatures[90].MaxTemp;
            let froidAvr = data.temperatures[90].MinTemp;
            let moyAvr = 0;

            let chaudMai = data.temperatures[120].MaxTemp;
            let froidMai = data.temperatures[120].MinTemp;
            let moyMai = 0;

            let chaudJui = data.temperatures[151].MaxTemp;
            let froidJui = data.temperatures[151].MinTemp;
            let moyJui = 0;

            let chaudJuil = data.temperatures[181].MaxTemp;
            let froidJuil = data.temperatures[181].MinTemp;
            let moyJuil = 0;

            let chaudAou = data.temperatures[212].MaxTemp;
            let froidAou = data.temperatures[212].MinTemp;
            let moyAou = 0;

            let chaudSep = data.temperatures[243].MaxTemp;
            let froidSep = data.temperatures[243].MinTemp;
            let moySep = 0;

            let chaudOct = data.temperatures[273].MaxTemp;
            let froidOct = data.temperatures[273].MinTemp;
            let moyOct = 0;

            let chaudNov = data.temperatures[304].MaxTemp;
            let froidNov = data.temperatures[304].MinTemp;
            let moyNov = 0;

            let chaudDec = data.temperatures[334].MaxTemp;
            let froidDec = data.temperatures[334].MinTemp;
            let moyDec = 0;

            if (url == '/janvier.html' || url == '/mars.html' || url == '/mai.html' || url == '/juillet.html' || url == '/aout.html' || url == '/octobre.html' || url == '/decembre.html') {

                let mois;
                if (url == '/janvier.html') {
                    mois = '01';
                } else if (url == '/mars.html') {
                    mois = '03';
                } else if (url == '/mai.html') {
                    mois = '05';
                } else if (url == '/juillet.html') {
                    mois = '07';
                } else if (url == '/aout.html') {
                    mois = '08';
                } else if (url == '/octobre.html') {
                    mois = '10';
                } else if (url == '/decembre.html') {
                    mois = '12';
                }

                let x = 0;
                

                for (let i = 0; i < data.temperatures.length; i++) {
                    let dateDuJour = data.temperatures[i].DateDuJour;
                    let moisTab = dateDuJour.substring(5, 7);

                    if (moisTab == mois) {
                        
                        x++;

                        if (x < 8) {
                            let parent = document.getElementById('tr1');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 15) {
                            let parent = document.getElementById('tr2');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 22) {
                            let parent = document.getElementById('tr3');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 29) {
                            let parent = document.getElementById('tr4');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 32) {
                            let parent = document.getElementById('tr5');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        }
                        
                        if (moisTab == '01') {
                            if(chaudJan < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudJan = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudJan == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidJan > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidJan = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidJan == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyJan += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '03') {
                            if(chaudMar < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudMar = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudMar == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            } 
                            if(froidMar > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidMar = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidMar == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyMar += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '05') {
                            if(chaudMai < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudMai = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudMai == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidMai > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidMai = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidMai == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyMai += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '07') {
                            if(chaudJuil < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudJuil = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudJuil == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidJuil > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidJuil = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidJuil == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyJuil += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '08') {
                            if(chaudAou < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudAou = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudAou == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            } 
                            if(froidAou > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidAou = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidAou == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyAou += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '10') {
                            if(chaudNov < data.temperatures[i + 1].MaxTemp && x < 31 ){
                                chaudNov = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudNov == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }  
                            if(froidNov > data.temperatures[i + 1].MinTemp && x < 31 ){
                                froidNov = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidNov == data.temperatures[i + 1].MinTemp && x < 31 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyNov += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        } else if (moisTab == '12') {
                            if(x < 31){
                                if(chaudDec < data.temperatures[i + 1].MaxTemp){
                                    chaudDec = data.temperatures[i + 1].MaxTemp;
                                    jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                                }else if(chaudDec == data.temperatures[i + 1].MaxTemp && x < 31 ){
                                    jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                                }
                                if(froidDec > data.temperatures[i + 1].MinTemp){
                                    froidDec = data.temperatures[i + 1].MinTemp;
                                    jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                                }else if(froidDec == data.temperatures[i + 1].MinTemp && x < 31 ){
                                    jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                                }
                            }

                            moyDec += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        }

                    }
                }

            } else if (url == '/avril.html' || url == '/juin.html' || url == '/septembre.html' || url == '/novembre.html') {

                let mois;
                if (url == '/avril.html') {
                    mois = '04';
                } else if (url == '/juin.html') {
                    mois = '06';
                } else if (url == '/septembre.html') {
                    mois = '09';
                } else if (url == '/novembre.html') {
                    mois = '11';
                }

                let x = 0;
                for (let i = 0; i < data.temperatures.length; i++) {
                    let dateDuJour = data.temperatures[i].DateDuJour;
                    let moisTab = dateDuJour.substring(5, 7);

                    if (moisTab == mois) {

                        x++;

                        if (x < 8) {
                            let parent = document.getElementById('tr1');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 15) {
                            let parent = document.getElementById('tr2');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 22) {
                            let parent = document.getElementById('tr3');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 29) {
                            let parent = document.getElementById('tr4');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 31) {
                            let parent = document.getElementById('tr5');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        }

                        if (moisTab == '04') {
                            if(chaudAvr < data.temperatures[i + 1].MaxTemp && x < 30 ){
                                chaudAvr = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudAvr == data.temperatures[i + 1].MaxTemp && x < 30 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidAvr > data.temperatures[i + 1].MinTemp && x < 30 ){
                                froidAvr = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidAvr == data.temperatures[i + 1].MinTemp && x < 30 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyAvr += (data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2;
                        } else if (moisTab == '06') {
                            if(chaudJui < data.temperatures[i + 1].MaxTemp && x < 30 ){
                                chaudJui = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudJui == data.temperatures[i + 1].MaxTemp && x < 30 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidJui > data.temperatures[i + 1].MinTemp && x < 30 ){
                                froidJui = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidJui == data.temperatures[i + 1].MinTemp && x < 30 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyJui += (data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2;
                        } else if (moisTab == '09') {
                            if(chaudSep < data.temperatures[i + 1].MaxTemp && x < 30 ){
                                chaudSep = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudSep == data.temperatures[i + 1].MaxTemp && x < 30 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidSep > data.temperatures[i + 1].MinTemp && x < 30 ){
                                froidSep = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidSep == data.temperatures[i + 1].MinTemp && x < 30 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moySep += (data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2;
                        } else if (moisTab == '11') {
                            if(chaudNov < data.temperatures[i + 1].MaxTemp && x < 30 ){
                                chaudNov = data.temperatures[i + 1].MaxTemp;
                                jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                            }else if(chaudNov == data.temperatures[i + 1].MaxTemp && x < 30 ){
                                jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            if(froidNov > data.temperatures[i + 1].MinTemp && x < 30 ){
                                froidNov = data.temperatures[i + 1].MinTemp;
                                jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                            }else if(froidNov == data.temperatures[i + 1].MinTemp && x < 30 ){
                                jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                            }
                            moyNov += (data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2;
                        }
                    }
                }

            } else if (url == '/fevrier.html') {
                
                let x = 0;
                for (let i = 0; i < data.temperatures.length; i++) {
                    let dateDuJour = data.temperatures[i].DateDuJour;
                    let moisTab = dateDuJour.substring(5, 7);

                    if (moisTab == '02') {

                        x++;

                        if (x < 8) {
                            let parent = document.getElementById('tr1');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 15) {
                            let parent = document.getElementById('tr2');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 22) {
                            let parent = document.getElementById('tr3');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        } else if (x < 29) {
                            let parent = document.getElementById('tr4');
                            let parent2 = document.createElement('td');

                            let date = document.createElement('p');
                            date.innerHTML = data.temperatures[i].DateDuJour;

                            date.setAttribute('class', 'fw-bold text-center fs-5')
                            parent2.appendChild(date);

                            let icon = document.createElement('img');
                            if (data.temperatures[i].Temp <= 0) {
                                icon.setAttribute('src', 'img/neigeP.png');
                            } else if (data.temperatures[i].Temp >= 20) {
                                icon.setAttribute('src', 'img/soleilP.png');
                            } else if (data.temperatures[i].Temp > 0 && data.temperatures[i].Temp <= 10) {
                                icon.setAttribute('src', 'img/pluieP.png');
                            } else if (data.temperatures[i].Temp > 10 && data.temperatures[i].Temp < 20) {
                                icon.setAttribute('src', 'img/nuageP.png');
                            }

                            icon.setAttribute('style', 'float:left; margin-right:8px;')
                            parent2.appendChild(icon);

                            let paragTemp = document.createElement('p');
                            let paragMinTemp = document.createElement('p');
                            let paragMaxTemp = document.createElement('p');

                            paragTemp.innerHTML = "Temp: " + data.temperatures[i].Temp + " °C";
                            paragMinTemp.innerHTML = "Temp Min: " + data.temperatures[i].MinTemp + " °C";
                            paragMaxTemp.innerHTML = "Temp Max: " + data.temperatures[i].MaxTemp + " °C";

                            paragTemp.setAttribute('class', 'mb-0 fw-bold')
                            paragMinTemp.setAttribute('class', 'mb-0')

                            parent2.appendChild(paragTemp);
                            parent2.appendChild(paragMinTemp);
                            parent2.appendChild(paragMaxTemp);

                            parent.appendChild(parent2);
                        }
                        
                        if(chaudFev < data.temperatures[i + 1].MaxTemp && x < 28 ){
                            chaudFev = data.temperatures[i + 1].MaxTemp;
                            jourLePlusChaud = data.temperatures[i + 1].DateDuJour;
                        }else if(chaudFev == data.temperatures[i + 1].MaxTemp && x < 30 ){
                            jourLePlusChaud = jourLePlusChaud + ' / ' + data.temperatures[i + 1].DateDuJour;
                        } 
                        if(froidFev > data.temperatures[i + 1].MinTemp && x < 28 ){
                            froidFev = data.temperatures[i + 1].MinTemp;
                            jourLePlusFroid = data.temperatures[i + 1].DateDuJour;
                        }else if(froidFev == data.temperatures[i + 1].MinTemp && x < 30 ){
                            jourLePlusFroid = jourLePlusFroid + ' / ' + data.temperatures[i + 1].DateDuJour;
                        }
                        moyFev += ((data.temperatures[i].MaxTemp + data.temperatures[i].MinTemp) / 2);
                        
                    }
                }
            }
            
            

            moyJan = Math.round(moyJan / 31);

            moyFev = Math.round(moyFev / 28);

            moyMar = Math.round(moyMar / 31);

            moyAvr = Math.round(moyAvr / 30);

            moyMai = Math.round(moyMai / 31);

            moyJui = Math.round(moyJui / 30);

            moyJuil = Math.round(moyJuil / 31);

            moyAou = Math.round(moyAou / 31);

            moySep = Math.round(moySep / 30);

            moyOct = Math.round(moyOct / 31);

            moyNov = Math.round(moyNov / 30);

            moyDec = Math.round(moyDec / 31);

            
            if (url == '/janvier.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudJan + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidJan + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyJan + ' °C';
                divMoy.appendChild(jourMoy);
            }else if (url == '/fevrier.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudFev + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidFev + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyFev + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/mars.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudMar + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidMar + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyMar + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/avril.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudAvr + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidAvr + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyAvr + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/mai.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudMai + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidMai + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyMai + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/juin.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudJui + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidJui + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyJui + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/juillet.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudJuil + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidJuil + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyJuil + ' °C';
                divMoy.appendChild(jourMoy);
            }else if (url == '/aout.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudAou + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidAou + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyAou + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/septembre.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudSep + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidSep + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moySep + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/octobre.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudOct + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidOct + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyOct + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/novembre.html'){
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudNov + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidNov + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyNov + ' °C';
                divMoy.appendChild(jourMoy);
            }else if(url == '/decembre.html') {
                let divJourChaud = document.getElementById('jourPlusChaud');
                let jourPlusChaud = document.createElement('p');
                jourPlusChaud.innerHTML = jourLePlusChaud;
                divJourChaud.appendChild(jourPlusChaud);

                let divJourFroid = document.getElementById('jourPlusFroid');
                let jourPlusFroid = document.createElement('p');
                jourPlusFroid.innerHTML = jourLePlusFroid;
                divJourFroid.appendChild(jourPlusFroid);

                let divChaud = document.getElementById('plusChaud');
                let jourChaud = document.createElement('p');
                jourChaud.innerHTML = 'Temperature: ' + chaudDec + ' °C';
                divChaud.appendChild(jourChaud);

                let divFroid = document.getElementById('plusFroid');
                let jourFroid = document.createElement('p');
                jourFroid.innerHTML = 'Temperature:' + froidDec + ' °C';
                divFroid.appendChild(jourFroid);

                let divMoy = document.getElementById('moyenne');
                let jourMoy = document.createElement('p');
                jourMoy.innerHTML = moyDec + ' °C';
                divMoy.appendChild(jourMoy);
            }

        })
}